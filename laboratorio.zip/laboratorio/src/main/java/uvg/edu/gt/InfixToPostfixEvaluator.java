package uvg.edu.gt;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
import java.util.Stack;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Vector;

// Clase para convertir expresión infix a postfix y evaluarla
public class InfixToPostfixEvaluator {
    // Método para convertir expresión infix a postfix
    public static String infixToPostfix(String expression) {
        StringBuilder result = new StringBuilder();
        Stack<Character> stack = new Stack<>();

        for (char c : expression.toCharArray()) {
            if (Character.isDigit(c)) {
                result.append(c);
            } else if (c == '(') {
                stack.push(c);
            } else if (c == ')') {
                while (!stack.isEmpty() && stack.peek() != '(') {
                    result.append(stack.pop());
                }
                stack.pop(); // Pop '('
            } else { // Operador encontrado
                while (!stack.isEmpty() && precedence(c) <= precedence(stack.peek())) {
                    result.append(stack.pop());
                }
                stack.push(c);
            }
        }

        while (!stack.isEmpty()) {
            result.append(stack.pop());
        }

        return result.toString();
    }

    // Método para evaluar la expresión postfix
    public static int evaluatePostfix(String expression) {
        Stack<Integer> stack = new Stack<>();

        for (char c : expression.toCharArray()) {
            if (Character.isDigit(c)) {
                stack.push(c - '0');
            } else {
                int operand2 = stack.pop();
                int operand1 = stack.pop();
                int result = performOperation(c, operand1, operand2);
                stack.push(result);
            }
        }

        return stack.pop();
    }

    // Método para determinar la precedencia de los operadores
    private static int precedence(char operator) {
        switch (operator) {
            case '+':
            case '-':
                return 1;
            case '*':
            case '/':
                return 2;
            default:
                return -1;
        }
    }

    // Método para realizar operaciones
    private static int performOperation(char operator, int operand1, int operand2) {
        switch (operator) {
            case '+':
                return operand1 + operand2;
            case '-':
                return operand1 - operand2;
            case '*':
                return operand1 * operand2;
            case '/':
                if (operand2 == 0) {
                    throw new ArithmeticException("División por cero");
                }
                return operand1 / operand2;
            default:
                throw new IllegalArgumentException("Operador no válido: " + operator);
        }
    }

    public static void main(String[] args) {
        // Pedir al usuario que elija la implementación del Stack
        Scanner scanner = new Scanner(System.in);
        System.out.println("Elija la implementación del Stack:");
        System.out.println("1. ArrayList");
        System.out.println("2. Vector");
        System.out.println("3. LinkedList");
        int choice = scanner.nextInt();
        Stack<Character> stack;
        switch (choice) {
            case 1:
                stack = new Stack<>();
                break;
            case 2:
                stack = new Stack<>();
                break;
            case 3:
                stack = new Stack<>();
                break;
            default:
                System.out.println("Opción inválida, utilizando ArrayList por defecto.");
                stack = new Stack<>();
                break;
        }

        // Leer la expresión infix del archivo datos.txt
        try (BufferedReader br = new BufferedReader(new FileReader("datos.txt"))) {
            String infixExpression = br.readLine();
            System.out.println("Expresión infix: " + infixExpression);

            // Convertir a postfix y evaluar
            String postfixExpression = infixToPostfix(infixExpression);
            System.out.println("Expresión postfix: " + postfixExpression);
            int result = evaluatePostfix(postfixExpression);
            System.out.println("Resultado: " + result);
        } catch (IOException e) {
            System.err.println("Error al leer el archivo.");
            e.printStackTrace();
        }
    }
}
